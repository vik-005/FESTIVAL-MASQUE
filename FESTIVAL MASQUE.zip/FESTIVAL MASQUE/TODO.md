- [x] Remplacer le timer fictif dans `index.html` par un vrai décompte
- [x] Fixer la date de début du festival au 26 juillet 2026
- [x] Mettre à jour le badge “Disponible pendant le festival · Xj Yh Zm”
- [ ] Tester visuellement en ouvrant `index.html`

